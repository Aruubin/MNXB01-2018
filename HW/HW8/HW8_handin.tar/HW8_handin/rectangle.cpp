#include "rectangle.h"

rectangle::rectangle(double base, double height) : shape(base, height) {
	
}

rectangle::~rectangle() {
	
}
